declare type AppSyncEvent = {
    info: {
        fieldName: string;
    };
    arguments: {
        title: string;
    };
};
